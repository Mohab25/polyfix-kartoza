import setuptools

setuptools.setup(
    name='kartoza-polyfix',
    version='0.1.1',
    description='a python package to fix polygon spikes',
    long_description='a python package to fix polygon spikes, built on top of fiona and shapely',
    author='kartoza',
    install_requires=[
        'fiona',
        'shapely>=1.8.0'
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),

)